from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    # База даних
    DATABASE_URL: str = "postgresql+psycopg2://postgres:postgres@localhost:5432/postgres"
    # JWT
    SECRET_KEY: str = "CHANGE_ME"  # обов'язково змініть у .env
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    EMAIL_TOKEN_EXPIRE_HOURS: int = 24
    # CORS
    CORS_ALLOW_ORIGINS: str = "*"  # CSV або *
    # Cloudinary
    CLOUDINARY_URL: Optional[str] = None
    # Rate limit для /me
    RATE_LIMIT_ME_CALLS: int = 5
    RATE_LIMIT_ME_WINDOW_SEC: int = 60
    # SMTP (опційно)
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
