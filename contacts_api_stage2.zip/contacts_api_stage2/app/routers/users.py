from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, status
from sqlalchemy.orm import Session
import cloudinary, cloudinary.uploader
from .. import models, schemas
from ..deps import get_current_user, rate_limit_me
from ..database import get_db
from ..settings import settings

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(get_current_user)):
    # Ліміт звернень до /me
    rate_limit_me(current_user.id)
    return current_user

@router.post("/me/avatar", status_code=status.HTTP_201_CREATED, response_model=schemas.UserOut)
def upload_avatar(file: UploadFile = File(...), db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if not settings.CLOUDINARY_URL:
        raise HTTPException(status_code=503, detail="Cloudinary is not configured")
    cloudinary.config(cloudinary_url=settings.CLOUDINARY_URL, secure=True)
    result = cloudinary.uploader.upload(file.file, folder="contacts_api/avatars", public_id=str(current_user.id), overwrite=True)
    url = result.get("secure_url")
    if not url:
        raise HTTPException(status_code=500, detail="Upload failed")
    current_user.avatar_url = url
    db.commit()
    db.refresh(current_user)
    return current_user
